
let suma = 10 + 5; 
let resta = 10 - 5; 
let multiplicacion = 10 * 5;
let division = 10 / 5; 

console.log(suma, resta, multiplicacion, division); 


let esIgual = '10' == '10'; 
let estrictamenteIgual = '10' === '10'; 

console.log(esIgual, estrictamenteIgual); 
