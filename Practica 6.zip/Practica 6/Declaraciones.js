// Declaración con var
var nombre = "Ixar";

let nombre = "Ixar";
console.log(nombre); 

let edad = 21;
console.log(edad); 

const pais = "El Salvador";
console.log(pais); 
