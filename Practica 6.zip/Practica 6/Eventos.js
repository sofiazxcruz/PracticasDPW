
let boton = document.getElementById("miBoton"); 


boton.addEventListener("click", function() {
    console.log("Botón clickeado"); 
    alert("Se hizo clic en el botón"); 
});
