
const persona = {
    nombre: "Ixar", 
    edad: 21, 
    profesion: "Ingeniero" 
};


console.log(persona.nombre); 
console.log(persona.edad); 
console.log(persona.profesion); 
