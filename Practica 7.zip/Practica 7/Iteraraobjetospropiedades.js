
const producto = {
    nombre: "Laptop",
    precio: 800,
    disponible: true
};


for (let propiedad in producto) {
    console.log(`${propiedad}: ${producto[propiedad]}`);
}
