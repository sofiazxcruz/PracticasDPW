
const estudiante = {
    nombre: "Ixar",
    edad: 21,
    direccion: {
        calle: "Calle Principal El sauce",
        ciudad: "El sauce"
    },
    materias: ["Matemáticas", "Programación", "Física"]
};


console.log(estudiante.direccion.ciudad); 
console.log(estudiante.materias[1]); 
