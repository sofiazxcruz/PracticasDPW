
const libro = {
    titulo: "El Quijote",
    autor: "Miguel de Cervantes"
};


libro.año = 1605;


libro.autor = "Cervantes";


console.log(libro);

